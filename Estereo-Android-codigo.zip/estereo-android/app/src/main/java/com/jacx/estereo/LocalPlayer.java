package com.jacx.estereo;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.util.Size;

import org.json.JSONArray;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/** El "iPod" de verdad: reproduce las canciones guardadas en la tablet con su propia sesión de música. */
class LocalPlayer implements MediaPlayer.OnCompletionListener, AudioManager.OnAudioFocusChangeListener {
    static class Track { long id, albumId, dur; String title, artist, album; }

    private final MainActivity a;
    private final AudioManager am;
    final MediaSession ms;
    private MediaPlayer mp;
    private final List<Track> q = new ArrayList<>();
    private int idx = -1;
    int repeat = 0; // 0 no, 1 una, 2 todas
    private boolean focusLost = false;
    private AudioFocusRequest afr;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final HashMap<Long, Bitmap> artCache = new HashMap<>();

    LocalPlayer(MainActivity a, AudioManager am) {
        this.a = a;
        this.am = am;
        ms = new MediaSession(a, "JACX-iPod");
        ms.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { if (extOn) a.ipToJs("resume"); else play(); }
            @Override public void onPause() { if (extOn) a.ipToJs("pause"); else pause(); }
            @Override public void onSkipToNext() { if (extOn) a.ipToJs("next"); else next(); }
            @Override public void onSkipToPrevious() { if (extOn) a.ipToJs("prev"); else prev(); }
            @Override public void onSeekTo(long pos) { seek(pos); }
            @Override public void onSkipToQueueItem(long id) { playIndex((int) id); }
            @Override public void onStop() { pause(); }
        });
    }

    // ---------- YouTube dentro del iPod: esta sesión lo anuncia al estéreo del carro / Bluetooth ----------
    boolean extOn = false;
    private String extKey = "";
    void ext(boolean on) {
        extOn = on;
        if (on) { if (mp != null && mp.isPlaying()) mp.pause(); ms.setActive(true); }
    }
    void extMeta(String title, String artist, String album, long dur, long pos, boolean playing) {
        if (!extOn) return;
        String k = title + "|" + artist;
        if (!k.equals(extKey)) {
            extKey = k;
            ms.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, title).putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                    .putString(MediaMetadata.METADATA_KEY_ALBUM, album).putLong(MediaMetadata.METADATA_KEY_DURATION, dur).build());
        }
        long acts = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS;
        ms.setPlaybackState(new PlaybackState.Builder().setActions(acts).setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, pos, 1f).build());
    }

    // ---------- biblioteca ----------
    static String library(Context c) {
        JSONArray out = new JSONArray();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        ArrayList<String> cols = new ArrayList<>();
        cols.add(MediaStore.Audio.Media._ID); cols.add(MediaStore.Audio.Media.TITLE); cols.add(MediaStore.Audio.Media.ARTIST);
        cols.add(MediaStore.Audio.Media.ALBUM); cols.add(MediaStore.Audio.Media.ALBUM_ID); cols.add(MediaStore.Audio.Media.DURATION);
        cols.add(MediaStore.Audio.Media.TRACK); cols.add(MediaStore.Audio.Media.YEAR); cols.add(MediaStore.Audio.Media.COMPOSER);
        cols.add(MediaStore.Audio.Media.DATE_ADDED); cols.add(MediaStore.Audio.Media.IS_MUSIC); cols.add(MediaStore.Audio.Media.IS_PODCAST);
        boolean hasAudiobook = Build.VERSION.SDK_INT >= 29, hasGenre = Build.VERSION.SDK_INT >= 30;
        if (hasAudiobook) cols.add(MediaStore.Audio.Media.IS_AUDIOBOOK);
        if (hasGenre) cols.add(MediaStore.Audio.Media.GENRE);
        try (Cursor cu = c.getContentResolver().query(uri, cols.toArray(new String[0]), MediaStore.Audio.Media.DURATION + ">20000", null, null)) {
            if (cu == null) return out.toString();
            while (cu.moveToNext()) {
                int i = 0;
                long id = cu.getLong(i++); String title = cu.getString(i++), artist = cu.getString(i++), album = cu.getString(i++);
                long albumId = cu.getLong(i++), dur = cu.getLong(i++); int track = cu.getInt(i++), year = cu.getInt(i++);
                String composer = cu.getString(i++); long added = cu.getLong(i++);
                int isMusic = cu.getInt(i++), isPod = cu.getInt(i++), isBook = hasAudiobook ? cu.getInt(i++) : 0;
                String genre = hasGenre ? cu.getString(i++) : null;
                String kind = isBook != 0 ? "b" : isPod != 0 ? "p" : isMusic != 0 ? "m" : "o";
                if (artist == null || artist.equals("<unknown>")) artist = "";
                JSONArray r = new JSONArray();
                r.put(id); r.put(title == null ? "" : title); r.put(artist); r.put(album == null ? "" : album); r.put(albumId);
                r.put(dur); r.put(track % 1000); r.put(year); r.put(genre == null ? "" : genre); r.put(composer == null ? "" : composer);
                r.put(kind); r.put(added);
                out.put(r);
            }
        } catch (Exception ignored) { }
        return out.toString();
    }

    Bitmap albumArt(long albumId, int size) {
        Long key = albumId * 10 + (size > 300 ? 1 : 0);
        if (artCache.containsKey(key)) return artCache.get(key);
        Bitmap bm = null;
        Uri art = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                Uri al = ContentUris.withAppendedId(MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI, albumId);
                bm = a.getContentResolver().loadThumbnail(al, new Size(size, size), null);
            }
        } catch (Exception ignored) { }
        if (bm == null) {
            try (InputStream is = a.getContentResolver().openInputStream(art)) { bm = BitmapFactory.decodeStream(is); } catch (Exception ignored) { }
        }
        if (artCache.size() > 80) artCache.clear();
        artCache.put(key, bm);
        return bm;
    }

    // ---------- reproducir ----------
    void setQueue(List<Track> t, int start) {
        q.clear(); q.addAll(t);
        ArrayList<MediaSession.QueueItem> items = new ArrayList<>();
        for (int i = 0; i < q.size() && i < 500; i++) {
            Track k = q.get(i);
            items.add(new MediaSession.QueueItem(new android.media.MediaDescription.Builder().setMediaId(String.valueOf(k.id)).setTitle(k.title).setSubtitle(k.artist).build(), i));
        }
        ms.setQueue(items);
        ms.setQueueTitle("JΛCX");
        playIndex(start);
    }

    void playIndex(int i) {
        if (q.isEmpty()) return;
        extOn = false; extKey = "";
        if (i < 0) i = 0;
        if (i >= q.size()) { if (repeat == 2) i = 0; else { pause(); return; } }
        idx = i;
        Track t = q.get(i);
        try {
            if (mp != null) { try { mp.release(); } catch (Exception ignored) { } }
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setWakeMode(a, PowerManager.PARTIAL_WAKE_LOCK);
            mp.setDataSource(a, ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, t.id));
            mp.setOnCompletionListener(this);
            mp.prepare();
            EqManager.attach(mp.getAudioSessionId());
            if (focus()) mp.start();
            ms.setActive(true);
            meta(t);
            state();
        } catch (Exception e) {
            // archivo dañado: brincar al siguiente
            h.postDelayed(() -> { if (idx == q.indexOf(t)) next(); }, 300);
        }
    }

    private boolean focus() {
        int r;
        if (Build.VERSION.SDK_INT >= 26) {
            if (afr == null) afr = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setOnAudioFocusChangeListener(this).build();
            r = am.requestAudioFocus(afr);
        } else r = am.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        return r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    void play() { if (mp == null) { if (!q.isEmpty()) playIndex(Math.max(0, idx)); return; } if (focus()) { mp.start(); state(); } }
    void pause() { if (mp != null && mp.isPlaying()) mp.pause(); state(); }
    void toggle() { if (mp != null && mp.isPlaying()) pause(); else play(); }
    void next() { if (repeat == 1) repeatSame(); else playIndex(idx + 1 >= q.size() ? (repeat == 2 ? 0 : q.size()) : idx + 1); }
    void prev() { if (mp != null && mp.getCurrentPosition() > 4000) { seek(0); return; } playIndex(Math.max(0, idx - 1)); }
    void seek(long ms0) { if (mp != null) { try { mp.seekTo((int) Math.max(0, ms0)); } catch (Exception ignored) { } state(); } }
    private void repeatSame() { seek(0); play(); }
    boolean active() { return mp != null && idx >= 0; }
    boolean playing() { try { return mp != null && mp.isPlaying(); } catch (Exception e) { return false; } }

    @Override public void onCompletion(MediaPlayer m) {
        if (repeat == 1) { repeatSame(); return; }
        if (idx + 1 < q.size()) playIndex(idx + 1); else if (repeat == 2) playIndex(0); else state();
    }

    @Override public void onAudioFocusChange(int f) {
        if (f == AudioManager.AUDIOFOCUS_LOSS || f == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) { if (playing()) { pause(); focusLost = f == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT; } }
        else if (f == AudioManager.AUDIOFOCUS_GAIN && focusLost) { focusLost = false; play(); }
    }

    private void meta(Track t) {
        MediaMetadata.Builder b = new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, t.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, t.artist)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, t.album)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, mp != null ? mp.getDuration() : t.dur)
                .putLong(MediaMetadata.METADATA_KEY_TRACK_NUMBER, idx + 1)
                .putLong(MediaMetadata.METADATA_KEY_NUM_TRACKS, q.size());
        Bitmap art = albumArt(t.albumId, 500);
        if (art != null) b.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art);
        ms.setMetadata(b.build());
    }

    void state() {
        long acts = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT
                | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_SKIP_TO_QUEUE_ITEM | PlaybackState.ACTION_STOP;
        int st = playing() ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
        long pos = 0;
        try { if (mp != null) pos = mp.getCurrentPosition(); } catch (Exception ignored) { }
        ms.setPlaybackState(new PlaybackState.Builder().setActions(acts).setState(st, pos, 1f).setActiveQueueItemId(idx).build());
    }

    void release() {
        try { if (mp != null) mp.release(); } catch (Exception ignored) { }
        mp = null;
        try { ms.release(); } catch (Exception ignored) { }
    }
}
