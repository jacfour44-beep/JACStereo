package com.jacx.estereo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.audiofx.AudioEffect;

/** Las apps de música avisan cuándo empiezan a sonar; aquí se le pone el ecualizador a ese sonido. */
public class EqReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent i) {
        int s = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1);
        if (s < 0) return;
        if (AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION.equals(i.getAction())) EqManager.release(s);
        else EqManager.attach(s);
    }
}
