package com.jacx.estereo;

import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.SystemClock;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Pequeño servidor en la red de la casa: el celular abre http://IP:8044/?k=CLAVE y controla el reproductor de la tablet. */
class RemoteServer extends Thread {
    private final MainActivity a;
    private final String key;
    private ServerSocket ss;
    private volatile boolean running = true;
    final ConcurrentLinkedQueue<String> events = new ConcurrentLinkedQueue<>();
    volatile long lastSeen = 0;
    volatile int port = 0;
    volatile String view = "";
    private String artKey = "";
    private String artData = null;

    RemoteServer(MainActivity a, String key) {
        this.a = a;
        this.key = key;
        setDaemon(true);
        setName("control-remoto");
    }

    void shutdown() {
        running = false;
        try { if (ss != null) ss.close(); } catch (Exception ignored) { }
    }

    @Override
    public void run() {
        try {
            try { ss = new ServerSocket(8044); } catch (Exception e) { ss = new ServerSocket(0); }
            port = ss.getLocalPort();
            while (running) {
                final Socket s = ss.accept();
                new Thread(() -> handle(s)).start();
            }
        } catch (Exception ignored) { }
    }

    String url() {
        String ip = localIp();
        if (ip == null || port == 0) return "";
        return "http://" + ip + ":" + port + "/?k=" + key;
    }

    private static String localIp() {
        try {
            String best = null;
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress ad : Collections.list(ni.getInetAddresses())) {
                    if (!(ad instanceof Inet4Address) || !ad.isSiteLocalAddress()) continue;
                    String n = ni.getName().toLowerCase();
                    if (n.startsWith("wlan") || n.startsWith("eth") || n.startsWith("ap")) return ad.getHostAddress();
                    if (best == null) best = ad.getHostAddress();
                }
            }
            return best;
        } catch (Exception e) { return null; }
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(6000);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
            String line = in.readLine();
            if (line == null) { s.close(); return; }
            while (true) { String h = in.readLine(); if (h == null || h.isEmpty()) break; }
            String[] parts = line.split(" ");
            String path = parts.length > 1 ? parts[1] : "/";
            String query = "";
            int qi = path.indexOf('?');
            if (qi >= 0) { query = path.substring(qi + 1); path = path.substring(0, qi); }
            Map<String, String> p = new HashMap<>();
            for (String kv : query.split("&")) {
                int e = kv.indexOf('=');
                if (e > 0) p.put(kv.substring(0, e), URLDecoder.decode(kv.substring(e + 1), "UTF-8"));
            }
            OutputStream out = s.getOutputStream();
            if (path.equals("/") || path.equals("/control")) {
                send(out, 200, "text/html; charset=utf-8", readAsset("control.html"));
            } else if (!key.equals(p.get("k"))) {
                send(out, 403, "text/plain; charset=utf-8", "Clave incorrecta".getBytes("UTF-8"));
            } else {
                lastSeen = SystemClock.elapsedRealtime();
                if (path.equals("/api/state")) send(out, 200, "application/json; charset=utf-8", state().getBytes("UTF-8"));
                else if (path.equals("/api/art")) send(out, 200, "text/plain; charset=utf-8", (artData == null ? "" : artData).getBytes("UTF-8"));
                else if (path.equals("/api/cmd")) {
                    String c = p.get("c");
                    if (c != null) {
                        if (c.equals("play") || c.equals("next") || c.equals("prev") || c.equals("volup") || c.equals("voldown")) a.remoteCmd(c);
                        events.add(c);
                    }
                    send(out, 200, "application/json; charset=utf-8", state().getBytes("UTF-8"));
                } else send(out, 404, "text/plain; charset=utf-8", "No".getBytes("UTF-8"));
            }
            out.flush();
            s.close();
        } catch (Exception e) {
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    private String state() {
        JSONObject o = new JSONObject();
        try {
            MediaController c = a.remoteController();
            String title = "", artist = "", album = "";
            long dur = 0;
            double pos = 0;
            int st = 0;
            Bitmap art = null;
            if (c != null) {
                MediaMetadata md = c.getMetadata();
                PlaybackState ps = c.getPlaybackState();
                if (md != null) {
                    CharSequence t = md.getText(MediaMetadata.METADATA_KEY_TITLE);
                    CharSequence ar = md.getText(MediaMetadata.METADATA_KEY_ARTIST);
                    CharSequence al = md.getText(MediaMetadata.METADATA_KEY_ALBUM);
                    title = t == null ? "" : t.toString();
                    artist = ar == null ? "" : ar.toString();
                    album = al == null ? "" : al.toString();
                    dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION);
                    art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                    if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                }
                if (ps != null) {
                    st = ps.getState();
                    pos = ps.getPosition();
                    if (st == PlaybackState.STATE_PLAYING && ps.getLastPositionUpdateTime() > 0)
                        pos += (SystemClock.elapsedRealtime() - ps.getLastPositionUpdateTime()) * ps.getPlaybackSpeed();
                }
            }
            String k = title + "|" + artist;
            if (!k.equals(artKey)) { artKey = k; artData = MainActivity.artToData(art); }
            else if (artData == null && art != null) artData = MainActivity.artToData(art);
            AudioManager am = a.remoteAudio();
            o.put("ok", title.length() > 0);
            o.put("title", title);
            o.put("artist", artist);
            o.put("album", album);
            o.put("dur", Math.max(0, dur) / 1000.0);
            o.put("pos", Math.max(0, pos) / 1000.0);
            o.put("playing", st == PlaybackState.STATE_PLAYING);
            o.put("art", artKey + (artData == null ? ":0" : ":1"));
            o.put("vol", am.getStreamVolume(AudioManager.STREAM_MUSIC));
            o.put("volMax", am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
            o.put("view", view);
        } catch (Exception ignored) { }
        return o.toString();
    }

    private byte[] readAsset(String name) {
        try (InputStream is = a.getAssets().open(name)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) b.write(buf, 0, n);
            return b.toByteArray();
        } catch (Exception e) {
            return "<h1>Falta el control</h1>".getBytes();
        }
    }

    private static void send(OutputStream out, int code, String type, byte[] body) throws Exception {
        String msg = code == 200 ? "OK" : code == 403 ? "Forbidden" : "Not Found";
        String h = "HTTP/1.1 " + code + " " + msg + "\r\nContent-Type: " + type + "\r\nContent-Length: " + body.length
                + "\r\nCache-Control: no-store\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n";
        out.write(h.getBytes("UTF-8"));
        out.write(body);
    }
}
