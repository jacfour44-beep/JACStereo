package com.jacx.estereo;

import android.service.notification.NotificationListenerService;

/** Solo existe para que Android le dé al estéreo permiso de ver qué música está sonando. */
public class MediaListener extends NotificationListenerService {
}
