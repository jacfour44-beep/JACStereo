package com.jacx.estereo;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.Visualizer;
import android.content.IntentFilter;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.app.SearchManager;
import android.media.MediaDescription;
import android.media.session.MediaSession;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.List;

/**
 * Estéreo JΛCX para Android.
 * La pantalla del estéreo es la misma que en la compu (assets/index.html); esta clase le da:
 *  - lo que suena en YouTube Music, Spotify, etc. (nombre, artista, portada, tiempo)
 *  - control de la música (play, pausa, siguiente, anterior, volumen)
 *  - el sonido real del celular para que los gráficos se muevan con la música
 */
public class MainActivity extends Activity {
    private WebView web;
    private MediaSessionManager msm;
    private ComponentName listener;
    private AudioManager am;
    private Bridge bridge;
    private RemoteServer remote;
    LocalPlayer local;

    // ---- control remoto desde el celular (misma red Wi-Fi) ----
    private void startRemote() {
        try {
            android.content.SharedPreferences sp = getSharedPreferences("jacx", MODE_PRIVATE);
            String k = sp.getString("remoteKey", null);
            if (k == null) { k = String.valueOf(1000 + new java.util.Random().nextInt(9000)); sp.edit().putString("remoteKey", k).apply(); }
            remote = new RemoteServer(this, k);
            remote.start();
        } catch (Exception ignored) { }
    }

    // ---- poner una canción en la app de música, con varios intentos ----
    // 1) pedírselo a la sesión de música (sin salir del reproductor); 2) si no cambió la canción, abrir la app con la búsqueda
    //    y regresar al reproductor; 3) si nada de eso existe, abrir los resultados de búsqueda de YouTube Music
    private final Handler qh = new Handler(android.os.Looper.getMainLooper());
    private String curTitle() {
        try { MediaController c = controller(); MediaMetadata md = c == null ? null : c.getMetadata(); CharSequence t = md == null ? null : md.getText(MediaMetadata.METADATA_KEY_TITLE); return t == null ? "" : t.toString(); }
        catch (Exception e) { return ""; }
    }
    void playQuery(final String q, final Bundle ex) {
        runOnUiThread(() -> {
            final String before = curTitle();
            boolean asked = false;
            try {
                MediaController c = controller();
                if (c != null) {
                    PlaybackState st = c.getPlaybackState();
                    long acts = st == null ? 0 : st.getActions();
                    if ((acts & PlaybackState.ACTION_PLAY_FROM_SEARCH) != 0 || st == null) { c.getTransportControls().playFromSearch(q, ex); asked = true; }
                }
            } catch (Exception ignored) { }
            if (asked) qh.postDelayed(() -> { if (curTitle().equals(before)) playByIntent(q, ex); }, 2500);
            else playByIntent(q, ex);
        });
    }
    private void playByIntent(String q, Bundle ex) {
        String pkg = prefPkg();
        if (pkg != null && (pkg.equals(getPackageName()) || getPackageManager().getLaunchIntentForPackage(pkg) == null)) pkg = null;
        boolean yt = pkg == null || pkg.contains("youtube.music");
        if (pkg == null) {
            Intent app = findApp(new String[]{"youtube.music", "apps.youtube.music", "ytmusic", "youtubemusic"}, "youtube music");
            pkg = app != null && app.getComponent() != null ? app.getComponent().getPackageName() : null;
        }
        Intent i = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
        i.putExtras(ex);
        i.putExtra(SearchManager.QUERY, q);
        if (pkg != null) i.setPackage(pkg);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        boolean ok = false;
        try { if (i.resolveActivity(getPackageManager()) != null) { startActivity(i); ok = true; } } catch (Exception ignored) { }
        if (!ok && !yt && pkg != null) {
            try { Intent l = getPackageManager().getLaunchIntentForPackage(pkg); if (l != null) { l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(l); } } catch (Exception ignored) { }
            return;
        }
        if (!ok) {
            Intent v = new Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(q)));
            if (pkg != null) v.setPackage(pkg);
            v.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(v); ok = true; } catch (Exception e) { v.setPackage(null); try { startActivity(v); } catch (Exception ignored) { } }
            return; // en los resultados la escoges tú
        }
        // ya que empezó a sonar, regresar al reproductor
        qh.postDelayed(() -> {
            try { Intent back = new Intent(MainActivity.this, MainActivity.class); back.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(back); } catch (Exception ignored) { }
        }, 3500);
    }
    /** La app de música que escogiste en el iPod (Spotify, YouTube Music...). */
    String prefPkg() { try { return getSharedPreferences("jacx", MODE_PRIVATE).getString("prefPkg", null); } catch (Exception e) { return null; } }
    static final String[] MUSIC_APPS = {"com.google.android.apps.youtube.music", "com.spotify.music", "deezer.android.app", "com.apple.android.music",
            "com.amazon.mp3", "com.aspiro.tidal", "com.soundcloud.android", "com.google.android.youtube"};
    String appLabel(String pkg) {
        try { return getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)).toString(); } catch (Exception e) { return pkg; }
    }
    /** YouTube Music: abrir la canción exacta (watch?v=ID) para que suene sola. */
    private static final java.util.regex.Pattern VID = java.util.regex.Pattern.compile("^[A-Za-z0-9_-]{11}$");
    private static final java.util.regex.Pattern VID_IN = java.util.regex.Pattern.compile("\"videoId\":\"([A-Za-z0-9_-]{11})\"");
    void ytDirect(final String title, final String artist, final String mid) {
        new Thread(() -> {
            String id = null;
            if (mid != null) { String m = mid.startsWith("yt:") ? mid.substring(3) : mid; if (VID.matcher(m).matches()) id = m; }
            if (id == null) { JSONArray r = ytFind((title + " " + (artist == null ? "" : artist)).trim()); if (r.length() > 0) id = r.optJSONObject(0).optString("id", null); }
            final String vid = id;
            runOnUiThread(() -> {
                if (vid == null) { Bundle ex = new Bundle(); ex.putString(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/audio"); ex.putString(MediaStore.EXTRA_MEDIA_TITLE, title); if (artist != null && !artist.isEmpty()) ex.putString(MediaStore.EXTRA_MEDIA_ARTIST, artist); playByIntent((title + " " + (artist == null ? "" : artist)).trim(), ex); return; }
                Intent app = findApp(new String[]{"youtube.music", "apps.youtube.music", "ytmusic", "youtubemusic"}, "youtube music");
                Intent v = new Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/watch?v=" + vid));
                if (app != null && app.getComponent() != null) v.setPackage(app.getComponent().getPackageName());
                v.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(v); } catch (Exception e) { v.setPackage(null); try { startActivity(v); } catch (Exception ignored) { } }
                qh.postDelayed(() -> { try { Intent back = new Intent(MainActivity.this, MainActivity.class); back.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(back); } catch (Exception ignored) { } }, 4000);
            });
        }).start();
    }
    /** Spotify y otras: si guardamos su id (spotify:track:...), abrirla directo. */
    boolean openUri(String pkg, String mid) {
        if (mid == null || !mid.contains(":")) return false;
        try { Intent v = new Intent(Intent.ACTION_VIEW, Uri.parse(mid)); if (pkg != null) v.setPackage(pkg); v.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (v.resolveActivity(getPackageManager()) == null) return false; startActivity(v);
            qh.postDelayed(() -> { try { Intent back = new Intent(MainActivity.this, MainActivity.class); back.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(back); } catch (Exception ignored) { } }, 4000);
            return true; } catch (Exception e) { return false; }
    }
    void fallbackPlay(String pkg, String title, String artist, String mid) {
        if (pkg == null || pkg.contains("youtube.music")) { ytDirect(title, artist, mid); return; }
        if (openUri(pkg, mid)) return;
        Bundle ex = new Bundle(); ex.putString(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/audio"); ex.putString(MediaStore.EXTRA_MEDIA_TITLE, title);
        if (artist != null && !artist.isEmpty()) ex.putString(MediaStore.EXTRA_MEDIA_ARTIST, artist);
        playQuery((title + " " + (artist == null ? "" : artist)).trim(), ex);
    }
    // ---------- reproductor de YouTube dentro del iPod ----------
    volatile boolean ipActive = false;
    void ipToJs(String c) {
        final String f = "resume".equals(c) || "pause".equals(c) ? "ipCmd('" + c + "')" : "play".equals(c) ? "playBtn()" : "next".equals(c) ? "nextBtn()" : "prevBtn()";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.__ipod&&window.__ipod." + f, null); });
    }
    private static String httpText(String url, int max) throws Exception {
        java.net.HttpURLConnection h = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        try {
            h.setConnectTimeout(7000); h.setReadTimeout(9000);
            h.setRequestProperty("User-Agent", DESK_UA);
            h.setRequestProperty("Accept-Language", "es-MX,es;q=0.9");
            h.setRequestProperty("Cookie", "CONSENT=YES+1; SOCS=CAI");
            int code = h.getResponseCode();
            if (code != 200) throw new Exception("HTTP " + code);
            java.io.InputStream in = h.getInputStream();
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0 && bo.size() < max) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } finally { h.disconnect(); }
    }
    static final String DESK_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    /** Búsqueda "oficial" de YouTube (la misma que usa su página): responde JSON directo. */
    static String ytApi(String q) throws Exception {
        java.net.HttpURLConnection h = (java.net.HttpURLConnection) new java.net.URL("https://www.youtube.com/youtubei/v1/search?prettyPrint=false&key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8").openConnection();
        try {
            h.setConnectTimeout(8000); h.setReadTimeout(10000); h.setDoOutput(true); h.setRequestMethod("POST");
            h.setRequestProperty("Content-Type", "application/json");
            h.setRequestProperty("User-Agent", DESK_UA);
            h.setRequestProperty("Origin", "https://www.youtube.com");
            h.setRequestProperty("X-YouTube-Client-Name", "1");
            h.setRequestProperty("X-YouTube-Client-Version", "2.20241001.00.00");
            JSONObject client = new JSONObject().put("clientName", "WEB").put("clientVersion", "2.20241001.00.00").put("hl", "es").put("gl", "MX");
            JSONObject body = new JSONObject().put("context", new JSONObject().put("client", client)).put("query", q).put("params", "EgIQAQ==");
            h.getOutputStream().write(body.toString().getBytes("UTF-8"));
            int code = h.getResponseCode();
            if (code != 200) throw new Exception("HTTP " + code);
            java.io.InputStream in = h.getInputStream();
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0 && bo.size() < 6_000_000) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } finally { h.disconnect(); }
    }
    static volatile String lastSearchErr = "";
    /** Busca en YouTube y regresa [{id,title,ch,len}] sin abrir ninguna app. */
    static JSONArray ytResults(String q) {
        JSONArray out = new JSONArray();
        lastSearchErr = "";
        try { collectVideos(new JSONObject(ytApi(q)), out); } catch (Exception e) { lastSearchErr = "api: " + e.getClass().getSimpleName() + " " + e.getMessage(); }
        if (out.length() > 0) return out;
        try {
            String html = httpText("https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(q, "UTF-8") + "&sp=EgIQAQ%253D%253D&hl=es&gl=MX", 6_000_000);
            int i = html.indexOf("ytInitialData");
            if (i < 0) return out;
            int st = html.indexOf('{', i);
            int depth = 0, end = -1; boolean str = false, esc = false;
            for (int k = st; k < html.length(); k++) {
                char ch = html.charAt(k);
                if (str) { if (esc) esc = false; else if (ch == '\\') esc = true; else if (ch == '"') str = false; continue; }
                if (ch == '"') str = true; else if (ch == '{') depth++; else if (ch == '}') { depth--; if (depth == 0) { end = k; break; } }
            }
            if (end < 0) return out;
            collectVideos(new JSONObject(html.substring(st, end + 1)), out);
        } catch (Exception e) { lastSearchErr += " | web: " + e.getClass().getSimpleName() + " " + e.getMessage(); }
        if (out.length() == 0 && lastSearchErr.isEmpty()) lastSearchErr = "sin resultados";
        return out;
    }
    private static String runsText(JSONObject o) {
        if (o == null) return "";
        String s = o.optString("simpleText", "");
        if (!s.isEmpty()) return s;
        JSONArray r = o.optJSONArray("runs");
        StringBuilder b = new StringBuilder();
        if (r != null) for (int i = 0; i < r.length(); i++) b.append(r.optJSONObject(i) == null ? "" : r.optJSONObject(i).optString("text", ""));
        return b.toString();
    }
    private static void collectVideos(Object node, JSONArray out) {
        if (out.length() >= 10 || node == null) return;
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject v = o.optJSONObject("videoRenderer");
            if (v != null && v.has("videoId")) {
                try {
                    JSONObject r = new JSONObject();
                    r.put("id", v.getString("videoId"));
                    r.put("title", runsText(v.optJSONObject("title")));
                    String ch = runsText(v.optJSONObject("ownerText")); if (ch.isEmpty()) ch = runsText(v.optJSONObject("longBylineText"));
                    r.put("ch", ch);
                    r.put("len", runsText(v.optJSONObject("lengthText")));
                    if (!r.getString("len").isEmpty()) out.put(r);
                } catch (Exception ignored) { }
                return;
            }
            JSONArray names = o.names();
            if (names != null) for (int i = 0; i < names.length(); i++) collectVideos(o.opt(names.optString(i)), out);
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) collectVideos(a.opt(i), out);
        }
    }
    /** Último recurso: abrir la búsqueda en un navegador escondido (como si la abrieras tú) y leer los resultados. */
    JSONArray ytViaWebView(final String q) {
        final JSONArray out = new JSONArray();
        final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
        runOnUiThread(() -> {
            try {
                final WebView w = new WebView(MainActivity.this);
                w.getSettings().setJavaScriptEnabled(true);
                w.getSettings().setDomStorageEnabled(true);
                w.getSettings().setUserAgentString(DESK_UA);
                w.setWebViewClient(new WebViewClient() {
                    boolean read = false;
                    @Override public void onPageFinished(WebView v, String url) {
                        if (read) return; read = true;
                        qh.postDelayed(() -> w.evaluateJavascript("(function(){try{return JSON.stringify(window.ytInitialData||null)}catch(e){return 'null'}})()", val -> {
                            try {
                                String txt = new JSONArray("[" + val + "]").getString(0);
                                if (txt != null && txt.startsWith("{")) collectVideos(new JSONObject(txt), out);
                                else lastSearchErr += " | nav: vacío";
                            } catch (Exception e) { lastSearchErr += " | nav: " + e.getClass().getSimpleName(); }
                            done.countDown();
                            try { w.destroy(); } catch (Exception ignored) { }
                        }), 1500);
                    }
                });
                w.loadUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q) + "&sp=EgIQAQ%253D%253D");
            } catch (Exception e) { lastSearchErr += " | nav: " + e.getClass().getSimpleName(); done.countDown(); }
        });
        try { done.await(20, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        return out;
    }
    JSONArray ytFind(String q) {
        JSONArray r = ytResults(q);
        if (r.length() == 0) r = ytViaWebView(q);
        if (r.length() > 0) lastSearchErr = "";
        return r;
    }
    void jsCallback(final String fn, final int token, final String json) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window." + fn + "&&window." + fn + "(" + token + "," + json + ")", null); });
    }
    MediaController remoteController() { return controller(); }
    AudioManager remoteAudio() { return am; }
    void remoteCmd(String c) { if (bridge != null) bridge.cmd(c); }
    private Visualizer vis;
    private final Object lock = new Object();
    private byte[] fft = new byte[0];
    private byte[] wave = new byte[0];
    private long visT = 0;
    private int visRate = 44100;
    private String artKey = "";
    private String artData = null;
    private boolean artPending = false;

    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.__back?window.__back():false", v -> { if (!"true".equals(v)) moveTaskToBack(true); });
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
        listener = new ComponentName(this, MediaListener.class);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);

        web = new WebView(this);
        web.setBackgroundColor(0xFF050506);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(web, true); } catch (Exception ignored) { }
        web.setWebChromeClient(new WebChromeClient());
        // las pantallas de la app (estéreo / reproductor clásico) se abren aquí mismo, nunca en otra app
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { if (!r.isForMainFrame()) return false; return !r.getUrl().toString().startsWith("file:///android_asset/"); }
            // el reproductor de YouTube interno vive en https://jacx.app/yt.html (servido desde la app) para que YouTube lo acepte
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                try {
                    Uri u = r.getUrl();
                    if ("jacx.app".equals(u.getHost())) {
                        String path = u.getPath() == null || u.getPath().equals("/") ? "yt.html" : u.getPath().substring(1);
                        String mime = path.endsWith(".html") ? "text/html" : path.endsWith(".js") ? "application/javascript" : path.endsWith(".css") ? "text/css" : "application/octet-stream";
                        return new android.webkit.WebResourceResponse(mime, "utf-8", getAssets().open(path));
                    }
                } catch (Exception ignored) { }
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String u) { return !u.startsWith("file:///android_asset/"); }
            @Override public void onPageStarted(WebView v, String u, Bitmap fav) {
                // en el iPod: sin ecualizador ni medidor de sonido para que la música suene a todo su volumen
                boolean ipod = u != null && u.contains("pantalla.html");
                visWanted = !ipod;
                if (ipod) stopVis(); else startVis();
                boolean eqIpod = getSharedPreferences("jacx", MODE_PRIVATE).getBoolean("ipodEq", false);
                EqManager.suspend(ipod && !eqIpod);
            }
        });
        bridge = new Bridge();
        web.addJavascriptInterface(bridge, "Android");
        startRemote();
        try { local = new LocalPlayer(this, am); } catch (Exception ignored) { }
        try { int bm = getSharedPreferences("jacx", MODE_PRIVATE).getInt("boostMb", 0); if (bm > 0) EqManager.setBoost(bm); } catch (Exception ignored) { }
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        IntentFilter ef = new IntentFilter();
        ef.addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION);
        ef.addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION);
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(eqRx, ef, RECEIVER_EXPORTED);
            else registerReceiver(eqRx, ef);
        } catch (Exception ignored) { }
        sessionFrom(getIntent());
    }

    private final EqReceiver eqRx = new EqReceiver();

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        sessionFrom(i);
    }

    /** Si YouTube Music abre el estéreo desde su botón "Ecualizador", trae el número de su sonido. */
    private void sessionFrom(Intent i) {
        if (i == null) return;
        int s = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1);
        if (s >= 0) EqManager.attach(s);
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(eqRx); } catch (Exception ignored) { }
        if (remote != null) remote.shutdown();
        if (local != null) local.release();
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideBars();
        startVis();
        if (web != null) web.evaluateJavascript("window.__androidResume&&window.__androidResume()", null);
        autoResume(700);
        autoResume(1800);
    }

    /** Si la música se pausó justo al cambiarse al estéreo, la vuelve a poner en play. */
    private void autoResume(long delay) {
        new Handler(getMainLooper()).postDelayed(() -> {
            try {
                MediaController c = controller();
                if (c == null) return;
                PlaybackState st = c.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PAUSED
                        && SystemClock.elapsedRealtime() - st.getLastPositionUpdateTime() < 8000) {
                    c.getTransportControls().play();
                }
            } catch (Exception ignored) { }
        }, delay);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // al salir a otra app: el iPod suelta su reproductor de YouTube si no está sonando (para no estorbarle a Spotify / YouTube Music)
        if (web != null) web.evaluateJavascript("window.__appHidden&&window.__appHidden()", null);
        stopVis();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        View d = getWindow().getDecorView();
        d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    private boolean hasAccess() {
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(getPackageName());
    }

    private boolean hasMic() {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    /** La sesión de música activa: primero la que está sonando. */
    private MediaController controller() {
        MediaController lc = null;
        try { if (local != null && local.active()) lc = local.ms.getController(); } catch (Exception ignored) { }
        if (lc != null && local.playing()) return lc;
        if (!hasAccess()) return lc;
        try {
            List<MediaController> list = msm.getActiveSessions(listener);
            if (list == null || list.isEmpty()) return lc;
            for (MediaController c : list) {
                PlaybackState st = c.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PLAYING) return c;
            }
            String pref = prefPkg();
            if (pref != null) {
                if (pref.equals(getPackageName()) && lc != null) return lc;
                for (MediaController c : list) if (pref.equals(c.getPackageName())) return c;
            }
            return lc != null ? lc : list.get(0);
        } catch (SecurityException e) {
            return lc;
        }
    }

    // ---- sonido del celular (para que los gráficos se muevan con la música) ----
    boolean visWanted = true;
    private void startVis() {
        if (!visWanted) return;
        if (vis != null || !hasMic()) return;
        try {
            vis = new Visualizer(0);
            vis.setEnabled(false);
            int[] range = Visualizer.getCaptureSizeRange();
            vis.setCaptureSize(Math.min(1024, range[1]));
            visRate = vis.getSamplingRate() / 1000;
            vis.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override
                public void onWaveFormDataCapture(Visualizer v, byte[] w, int rate) {
                    synchronized (lock) { wave = w.clone(); }
                }

                @Override
                public void onFftDataCapture(Visualizer v, byte[] f, int rate) {
                    synchronized (lock) { fft = f.clone(); visT = SystemClock.uptimeMillis(); }
                }
            }, Visualizer.getMaxCaptureRate(), true, true);
            vis.setEnabled(true);
        } catch (Exception e) {
            vis = null;
        }
    }

    private void stopVis() {
        if (vis != null) {
            try { vis.setEnabled(false); vis.release(); } catch (Exception ignored) { }
            vis = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        startVis();
        if (web != null) web.evaluateJavascript("window.__androidResume&&window.__androidResume()", null);
    }

    static String artToData(Bitmap bm) {
        if (bm == null) return null;
        try {
            int w = bm.getWidth(), h = bm.getHeight(), m = Math.max(w, h);
            Bitmap sm = m > 300 ? Bitmap.createScaledBitmap(bm, Math.max(1, w * 300 / m), Math.max(1, h * 300 / m), true) : bm;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            sm.compress(Bitmap.CompressFormat.JPEG, 82, out);
            return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }

    private void mediaKey(int code) {
        long now = SystemClock.uptimeMillis();
        am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0));
        am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0));
    }

    /** Lo que la pantalla del estéreo (JavaScript) puede pedirle al celular. */
    public class Bridge {
        @JavascriptInterface
        public boolean hasAccess() { return MainActivity.this.hasAccess(); }

        @JavascriptInterface
        public boolean hasMic() { return MainActivity.this.hasMic(); }

        @JavascriptInterface
        public void askAccess() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
                catch (ActivityNotFoundException e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            });
        }

        @JavascriptInterface
        public void askMic() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            });
        }

        @JavascriptInterface
        public String media() {
            try {
                JSONObject o = new JSONObject();
                MediaController c = controller();
                if (c == null) { o.put("ok", false); o.put("access", hasAccess()); return o.toString(); }
                MediaMetadata md = c.getMetadata();
                PlaybackState st = c.getPlaybackState();
                String title = "", artist = "", album = "";
                long dur = 0;
                Bitmap art = null;
                if (md != null) {
                    CharSequence t = md.getText(MediaMetadata.METADATA_KEY_TITLE);
                    CharSequence a = md.getText(MediaMetadata.METADATA_KEY_ARTIST);
                    if (a == null) a = md.getText(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
                    CharSequence al = md.getText(MediaMetadata.METADATA_KEY_ALBUM);
                    title = t == null ? "" : t.toString();
                    artist = a == null ? "" : a.toString();
                    album = al == null ? "" : al.toString();
                    dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION);
                    art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                    if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                    if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                }
                int state = st == null ? 0 : st.getState();
                double pos = 0;
                if (st != null) {
                    pos = st.getPosition();
                    if (state == PlaybackState.STATE_PLAYING && st.getLastPositionUpdateTime() > 0) {
                        pos += (SystemClock.elapsedRealtime() - st.getLastPositionUpdateTime()) * st.getPlaybackSpeed();
                    }
                }
                String key = title + "|" + artist;
                if (!key.equals(artKey)) { artKey = key; artData = artToData(art); artPending = true; }
                else if (artData == null && art != null) { artData = artToData(art); artPending = true; }
                o.put("ok", title.length() > 0);
                o.put("app", c.getPackageName());
                o.put("title", title);
                o.put("artist", artist);
                o.put("album", album);
                try { String mid = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_MEDIA_ID); if (mid != null) o.put("mid", mid); } catch (Exception ignored) { }
                o.put("dur", Math.max(0, dur) / 1000.0);
                o.put("pos", Math.max(0, pos) / 1000.0);
                o.put("status", state == PlaybackState.STATE_PLAYING ? 4 : 5);
                if (artPending) { o.put("artNew", true); o.put("art", artData == null ? JSONObject.NULL : artData); artPending = false; }
                return o.toString();
            } catch (Exception e) {
                return "{\"ok\":false}";
            }
        }

        @JavascriptInterface
        public void cmd(String c) {
            if ("volup".equals(c)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return; }
            if ("voldown".equals(c)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return; }
            if (ipActive && ("play".equals(c) || "next".equals(c) || "prev".equals(c))) { ipToJs(c); return; }
            MediaController m = controller();
            if (m != null) {
                MediaController.TransportControls tc = m.getTransportControls();
                PlaybackState st = m.getPlaybackState();
                boolean playing = st != null && st.getState() == PlaybackState.STATE_PLAYING;
                if ("play".equals(c)) { if (playing) tc.pause(); else tc.play(); }
                else if ("next".equals(c)) tc.skipToNext();
                else if ("prev".equals(c)) tc.skipToPrevious();
            } else {
                if ("play".equals(c)) mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);
                else if ("next".equals(c)) mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT);
                else if ("prev".equals(c)) mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS);
            }
        }

        /** Espectro (512 valores 0-255) + forma de onda (1024 bytes), en base64. Vacío si no hay sonido. */
        @JavascriptInterface
        public String audio() {
            byte[] f, w;
            long t;
            synchronized (lock) { f = fft; w = wave; t = visT; }
            if (f.length < 4 || SystemClock.uptimeMillis() - t > 1500) return "";
            int n = f.length / 2;
            byte[] out = new byte[n + w.length];
            for (int k = 0; k < n; k++) {
                double re, im;
                if (k == 0) { re = f[0]; im = 0; }
                else { re = f[2 * k]; im = f[2 * k + 1]; }
                double mag = Math.hypot(re, im);
                double db = 20 * Math.log10(mag / 128.0 + 1e-6);
                int v = (int) Math.round((db + 62) / 62 * 255);
                out[k] = (byte) Math.max(0, Math.min(255, v));
            }
            System.arraycopy(w, 0, out, n, w.length);
            return Base64.encodeToString(out, Base64.NO_WRAP);
        }

        @JavascriptInterface
        public int rate() { return visRate; }

        @JavascriptInterface
        public void resetArt() { artKey = ""; }

        /** Lista "a continuación" de la app de música (si la comparte). */
        @JavascriptInterface
        public String queue() {
            JSONArray arr = new JSONArray();
            try {
                MediaController c = controller();
                if (c == null) return arr.toString();
                List<MediaSession.QueueItem> q = c.getQueue();
                if (q == null) return arr.toString();
                PlaybackState st = c.getPlaybackState();
                long active = st == null ? -1 : st.getActiveQueueItemId();
                int n = 0;
                for (MediaSession.QueueItem it : q) {
                    if (n++ >= 60) break;
                    MediaDescription d = it.getDescription();
                    JSONObject o = new JSONObject();
                    o.put("id", it.getQueueId());
                    o.put("title", d.getTitle() == null ? "" : d.getTitle().toString());
                    o.put("artist", d.getSubtitle() == null ? "" : d.getSubtitle().toString());
                    o.put("now", it.getQueueId() == active);
                    Bitmap ic = d.getIconBitmap();
                    if (ic != null) {
                        try {
                            Bitmap sm = Bitmap.createScaledBitmap(ic, 96, Math.max(1, ic.getHeight() * 96 / Math.max(1, ic.getWidth())), true);
                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                            sm.compress(Bitmap.CompressFormat.JPEG, 75, out);
                            o.put("art", "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
                        } catch (Exception ignored) { }
                    } else if (d.getIconUri() != null) o.put("art", d.getIconUri().toString());
                    arr.put(o);
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public void skipTo(String id) {
            try { MediaController c = controller(); if (c != null) c.getTransportControls().skipToQueueItem(Long.parseLong(id)); } catch (Exception ignored) { }
        }

        /** Pide a la app de música que toque algo: una búsqueda ("artista canción") o, vacío, una mezcla. */
        @JavascriptInterface
        public void search(String q) {
            Bundle ex = new Bundle();
            ex.putString(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*");
            playQuery(q == null ? "" : q, ex);
        }

        /** Abre la búsqueda dentro de la app de música (para escoger tú la canción). */
        @JavascriptInterface
        public void openSearch(String q) {
            runOnUiThread(() -> {
                Intent app = findApp(new String[]{"youtube.music", "apps.youtube.music", "ytmusic"}, "youtube music");
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(q == null ? "" : q)));
                if (app != null && app.getComponent() != null) i.setPackage(app.getComponent().getPackageName());
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(i); } catch (Exception e) { i.setPackage(null); try { startActivity(i); } catch (Exception ignored) { } }
            });
        }

        /** Lo que mandó el control remoto (rueda, OK, MENU...) y si está conectado. */
        @JavascriptInterface
        public String remote() {
            try {
                JSONObject o = new JSONObject();
                org.json.JSONArray ev = new org.json.JSONArray();
                if (remote != null) { String e; while ((e = remote.events.poll()) != null) ev.put(e); }
                o.put("ev", ev);
                o.put("on", remote != null && remote.lastSeen > 0 && SystemClock.elapsedRealtime() - remote.lastSeen < 4000);
                return o.toString();
            } catch (Exception e) { return "{\"ev\":[],\"on\":false}"; }
        }

        /** Volumen extra en milibeles (0 = normal, 600 = +6 dB...). Se guarda para la próxima vez. */
        @JavascriptInterface
        public int boost(int mb) {
            getSharedPreferences("jacx", MODE_PRIVATE).edit().putInt("boostMb", mb).apply();
            return EqManager.setBoost(mb);
        }

        @JavascriptInterface
        public int boostLevel() { return EqManager.boostMb; }

        /** Tocar una canción de tu historial en la app donde la escuchaste. */
        @JavascriptInterface
        public void playSong(String title, String artist, String album, String mid, String app) {
            try {
                String pkg = app != null && !app.isEmpty() && !app.equals(getPackageName()) ? app : prefPkg();
                if (pkg != null && pkg.equals(getPackageName())) pkg = null;
                // 1) si la app sigue abierta y acepta el id, que lo toque sin salir del iPod
                if (mid != null && !mid.isEmpty() && pkg != null && hasAccess()) {
                    List<MediaController> list = msm.getActiveSessions(listener);
                    if (list != null) for (MediaController c : list) if (pkg.equals(c.getPackageName())) {
                        PlaybackState st = c.getPlaybackState();
                        if (st != null && (st.getActions() & PlaybackState.ACTION_PLAY_FROM_MEDIA_ID) != 0) {
                            final String before = curTitle(); final MediaController cc = c; final String fp = pkg, ft = title, fa = artist, fm = mid;
                            runOnUiThread(() -> { try { cc.getTransportControls().playFromMediaId(fm, null); } catch (Exception ignored) { } });
                            qh.postDelayed(() -> { if (curTitle().equals(before)) fallbackPlay(fp, ft, fa, fm); }, 2500);
                            return;
                        }
                    }
                }
                fallbackPlay(pkg, title, artist, mid);
            } catch (Exception e) { fallbackPlay(null, title, artist, mid); }
        }

        /** Pide una canción exacta (título + artista + álbum) para que la app de música no escoja otra. */
        @JavascriptInterface
        public void searchSong(String title, String artist, String album) {
            Bundle ex = new Bundle();
            ex.putString(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/audio");
            if (title != null) ex.putString(MediaStore.EXTRA_MEDIA_TITLE, title);
            if (artist != null && !artist.isEmpty()) ex.putString(MediaStore.EXTRA_MEDIA_ARTIST, artist);
            if (album != null && !album.isEmpty()) ex.putString(MediaStore.EXTRA_MEDIA_ALBUM, album);
            playQuery(((title == null ? "" : title) + " " + (artist == null ? "" : artist)).trim(), ex);
        }

        // ---------- biblioteca de la tablet (el iPod de verdad) ----------
        @JavascriptInterface
        public boolean libPerm() {
            String p = Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : Manifest.permission.READ_EXTERNAL_STORAGE;
            return Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void askLibPerm() {
            runOnUiThread(() -> {
                String p = Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : Manifest.permission.READ_EXTERNAL_STORAGE;
                if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{p}, 7);
            });
        }

        @JavascriptInterface
        public String library() { return libPerm() ? LocalPlayer.library(MainActivity.this) : "[]"; }

        @JavascriptInterface
        public String albumArt(String albumId, int size) {
            try { if (local == null) return ""; String d = artToData(local.albumArt(Long.parseLong(albumId), Math.max(64, Math.min(600, size)))); return d == null ? "" : d; }
            catch (Exception e) { return ""; }
        }

        /** Toca una lista de canciones de la tablet empezando en "index". tracks = [[id,título,artista,álbum,albumId,dur],...] */
        @JavascriptInterface
        public void lplay(String tracks, int index) {
            try {
                org.json.JSONArray arr = new org.json.JSONArray(tracks);
                java.util.ArrayList<LocalPlayer.Track> list = new java.util.ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    org.json.JSONArray r = arr.getJSONArray(i);
                    LocalPlayer.Track t = new LocalPlayer.Track();
                    t.id = r.getLong(0); t.title = r.optString(1); t.artist = r.optString(2); t.album = r.optString(3); t.albumId = r.optLong(4); t.dur = r.optLong(5);
                    list.add(t);
                }
                runOnUiThread(() -> { if (local != null) local.setQueue(list, index); });
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void lrepeat(int mode) { if (local != null) local.repeat = mode; }

        @JavascriptInterface
        public boolean localActive() { return local != null && local.active(); }

        /** Las apps de música: las que están sonando o abiertas y las instaladas. */
        @JavascriptInterface
        public String players() {
            JSONArray out = new JSONArray();
            try {
                java.util.HashSet<String> seen = new java.util.HashSet<>();
                String pref = prefPkg();
                if (local != null && local.active()) {
                    JSONObject o = new JSONObject(); o.put("pkg", getPackageName()); o.put("label", "Este iPod (canciones de la tablet)");
                    o.put("playing", local.playing()); o.put("on", true); o.put("pref", getPackageName().equals(pref)); out.put(o); seen.add(getPackageName());
                }
                if (hasAccess()) {
                    List<MediaController> list = msm.getActiveSessions(listener);
                    if (list != null) for (MediaController c : list) {
                        String pk = c.getPackageName(); if (seen.contains(pk)) continue; seen.add(pk);
                        JSONObject o = new JSONObject(); o.put("pkg", pk); o.put("label", appLabel(pk)); o.put("on", true);
                        PlaybackState st = c.getPlaybackState(); o.put("playing", st != null && st.getState() == PlaybackState.STATE_PLAYING);
                        MediaMetadata md = c.getMetadata(); CharSequence t = md == null ? null : md.getText(MediaMetadata.METADATA_KEY_TITLE);
                        CharSequence a = md == null ? null : md.getText(MediaMetadata.METADATA_KEY_ARTIST);
                        o.put("title", t == null ? "" : t.toString()); o.put("artist", a == null ? "" : a.toString()); o.put("pref", pk.equals(pref)); out.put(o);
                    }
                }
                for (String pk : MUSIC_APPS) {
                    if (seen.contains(pk) || getPackageManager().getLaunchIntentForPackage(pk) == null) continue; seen.add(pk);
                    JSONObject o = new JSONObject(); o.put("pkg", pk); o.put("label", appLabel(pk)); o.put("on", false); o.put("playing", false); o.put("pref", pk.equals(pref)); out.put(o);
                }
            } catch (Exception ignored) { }
            return out.toString();
        }

        /** Escoger qué app controla el iPod. Si está abierta le da play; si no, la abre. */
        @JavascriptInterface
        public void usePlayer(final String pkg) {
            getSharedPreferences("jacx", MODE_PRIVATE).edit().putString("prefPkg", pkg).apply();
            runOnUiThread(() -> {
                try {
                    if (pkg.equals(getPackageName())) { if (local != null) local.play(); return; }
                    if (local != null && local.playing()) local.pause();
                    MediaController found = null;
                    if (hasAccess()) { List<MediaController> list = msm.getActiveSessions(listener); if (list != null) for (MediaController c : list) if (pkg.equals(c.getPackageName())) found = c; }
                    if (found != null) { for (MediaController c : msm.getActiveSessions(listener)) if (c != found) { PlaybackState st = c.getPlaybackState(); if (st != null && st.getState() == PlaybackState.STATE_PLAYING) c.getTransportControls().pause(); } found.getTransportControls().play(); return; }
                    Intent l = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (l != null) { l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(l); }
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public String prefApp() { String p = prefPkg(); return p == null ? "" : p; }

        /** Adelantar o regresar la canción (milisegundos). */
        @JavascriptInterface
        public void seekTo(long ms) {
            try { MediaController c = controller(); if (c != null) c.getTransportControls().seekTo(Math.max(0, ms)); } catch (Exception ignored) { }
        }

        /** Volumen real de música: "actual,máximo". */
        @JavascriptInterface
        public String vol() { return am.getStreamVolume(AudioManager.STREAM_MUSIC) + "," + am.getStreamMaxVolume(AudioManager.STREAM_MUSIC); }

        @JavascriptInterface
        public void setVol(int n) {
            int mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(0, Math.min(mx, n)), 0);
        }

        @JavascriptInterface
        public void ipodEq(boolean on) {
            getSharedPreferences("jacx", MODE_PRIVATE).edit().putBoolean("ipodEq", on).apply();
            EqManager.suspend(!on);
        }

        /** Buscar en YouTube (para tocarlo dentro del iPod). Responde en window.__ytRes(token, lista). */
        @JavascriptInterface
        public void ytSearch(final String q, final int token) {
            new Thread(() -> jsCallback("__ytRes", token, ytFind(q == null ? "" : q).toString())).start();
        }

        /** Descargar datos de álbumes (catálogo de iTunes). Responde en window.__httpRes(token, texto). */
        @JavascriptInterface
        public void httpGet(final String url, final int token) {
            new Thread(() -> {
                String body = "";
                try { if (url != null && url.startsWith("https://itunes.apple.com/")) body = httpText(url, 2_000_000); } catch (Exception ignored) { }
                jsCallback("__httpRes", token, JSONObject.quote(body));
            }).start();
        }

        /** El iPod está tocando YouTube por dentro: los botones (control remoto, audífonos, estéreo del carro) van para él. */
        @JavascriptInterface
        public void ipActive(boolean on) {
            ipActive = on;
            if (local != null) runOnUiThread(() -> local.ext(on));
        }

        @JavascriptInterface
        public void ipMeta(String title, String artist, String album, double dur, double pos, boolean playing) {
            if (local != null) runOnUiThread(() -> local.extMeta(title, artist, album, (long) (dur * 1000), (long) (pos * 1000), playing));
        }

        @JavascriptInterface
        public String searchErr() { return lastSearchErr == null ? "" : lastSearchErr; }

        @JavascriptInterface
        public boolean ipodEqOn() { return getSharedPreferences("jacx", MODE_PRIVATE).getBoolean("ipodEq", false); }

        @JavascriptInterface
        public void setView(String v) { if (remote != null) remote.view = v == null ? "" : v; }

        @JavascriptInterface
        public String remoteUrl() { return remote == null ? "" : remote.url(); }

        @JavascriptInterface
        public void orient(String m) {
            // "auto" gira solo con el sensor (aunque la tablet tenga el giro bloqueado)
            final int o = "auto".equals(m) ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
                    : "port".equals(m) ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
            runOnUiThread(() -> setRequestedOrientation(o));
        }

        /** Aplica el preset del ecualizador al sonido real. Regresa cuántos ecualizadores quedaron activos. */
        @JavascriptInterface
        public int eq(String csv) {
            try {
                String[] p = csv.split(",");
                float[] w = new float[p.length];
                for (int k = 0; k < p.length; k++) w[k] = Float.parseFloat(p[k]);
                return EqManager.set(w);
            } catch (Exception e) { return 0; }
        }

        @JavascriptInterface
        public int battery() {
            try {
                BatteryManager bm = (BatteryManager) getSystemService(BATTERY_SERVICE);
                return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            } catch (Exception e) { return -1; }
        }

        @JavascriptInterface
        public void openApp(String id) {
            final String[] words;
            final String url;
            switch (id) {
                case "spotify": words = new String[]{"spotify"}; url = "https://open.spotify.com"; break;
                case "deezer": words = new String[]{"deezer"}; url = "https://www.deezer.com"; break;
                case "apple": words = new String[]{"apple.android.music"}; url = "https://music.apple.com"; break;
                case "amazon": words = new String[]{"amazon.mp3", "amazon.music"}; url = "https://music.amazon.com"; break;
                case "tidal": words = new String[]{"tidal"}; url = "https://listen.tidal.com"; break;
                case "soundcloud": words = new String[]{"soundcloud"}; url = "https://soundcloud.com"; break;
                default: words = new String[]{"youtube.music", "ytmusic", "youtubemusic"}; url = "https://music.youtube.com";
            }
            runOnUiThread(() -> {
                Intent i = findApp(words, id.equals("ytmusic") || id.isEmpty() ? "youtube music" : null);
                if (i == null) i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                try { startActivity(i); } catch (ActivityNotFoundException ignored) { }
            });
        }
    }

    /** Busca la app instalada aunque sea una versión modificada (por nombre del paquete o por el nombre que se ve). */
    private Intent findApp(String[] words, String label) {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        String found = null;
        for (android.content.pm.ResolveInfo r : apps) {
            String pkg = r.activityInfo.packageName.toLowerCase();
            for (String w : words) if (pkg.contains(w)) { found = r.activityInfo.packageName; break; }
            if (found != null) break;
        }
        if (found == null && label != null) {
            for (android.content.pm.ResolveInfo r : apps) {
                CharSequence l = r.loadLabel(pm);
                if (l != null && l.toString().toLowerCase().contains(label)) { found = r.activityInfo.packageName; break; }
            }
        }
        return found == null ? null : pm.getLaunchIntentForPackage(found);
    }
}
