package com.jacx.estereo;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.Visualizer;
import android.content.IntentFilter;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.app.SearchManager;
import android.media.MediaDescription;
import android.media.session.MediaSession;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.List;

/**
 * Estéreo JΛCX para Android.
 * La pantalla del estéreo es la misma que en la compu (assets/index.html); esta clase le da:
 *  - lo que suena en YouTube Music, Spotify, etc. (nombre, artista, portada, tiempo)
 *  - control de la música (play, pausa, siguiente, anterior, volumen)
 *  - el sonido real del celular para que los gráficos se muevan con la música
 */
public class MainActivity extends Activity {
    private WebView web;
    private MediaSessionManager msm;
    private ComponentName listener;
    private AudioManager am;
    private Visualizer vis;
    private final Object lock = new Object();
    private byte[] fft = new byte[0];
    private byte[] wave = new byte[0];
    private long visT = 0;
    private int visRate = 44100;
    private String artKey = "";
    private String artData = null;
    private boolean artPending = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
        listener = new ComponentName(this, MediaListener.class);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);

        web = new WebView(this);
        web.setBackgroundColor(0xFF050506);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        IntentFilter ef = new IntentFilter();
        ef.addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION);
        ef.addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION);
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(eqRx, ef, RECEIVER_EXPORTED);
            else registerReceiver(eqRx, ef);
        } catch (Exception ignored) { }
        sessionFrom(getIntent());
    }

    private final EqReceiver eqRx = new EqReceiver();

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        sessionFrom(i);
    }

    /** Si YouTube Music abre el estéreo desde su botón "Ecualizador", trae el número de su sonido. */
    private void sessionFrom(Intent i) {
        if (i == null) return;
        int s = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1);
        if (s >= 0) EqManager.attach(s);
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(eqRx); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideBars();
        startVis();
        if (web != null) web.evaluateJavascript("window.__androidResume&&window.__androidResume()", null);
        autoResume(700);
        autoResume(1800);
    }

    /** Si la música se pausó justo al cambiarse al estéreo, la vuelve a poner en play. */
    private void autoResume(long delay) {
        new Handler(getMainLooper()).postDelayed(() -> {
            try {
                MediaController c = controller();
                if (c == null) return;
                PlaybackState st = c.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PAUSED
                        && SystemClock.elapsedRealtime() - st.getLastPositionUpdateTime() < 8000) {
                    c.getTransportControls().play();
                }
            } catch (Exception ignored) { }
        }, delay);
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopVis();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        View d = getWindow().getDecorView();
        d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    private boolean hasAccess() {
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(getPackageName());
    }

    private boolean hasMic() {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    /** La sesión de música activa: primero la que está sonando. */
    private MediaController controller() {
        if (!hasAccess()) return null;
        try {
            List<MediaController> list = msm.getActiveSessions(listener);
            if (list == null || list.isEmpty()) return null;
            for (MediaController c : list) {
                PlaybackState st = c.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PLAYING) return c;
            }
            return list.get(0);
        } catch (SecurityException e) {
            return null;
        }
    }

    // ---- sonido del celular (para que los gráficos se muevan con la música) ----
    private void startVis() {
        if (vis != null || !hasMic()) return;
        try {
            vis = new Visualizer(0);
            vis.setEnabled(false);
            int[] range = Visualizer.getCaptureSizeRange();
            vis.setCaptureSize(Math.min(1024, range[1]));
            visRate = vis.getSamplingRate() / 1000;
            vis.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override
                public void onWaveFormDataCapture(Visualizer v, byte[] w, int rate) {
                    synchronized (lock) { wave = w.clone(); }
                }

                @Override
                public void onFftDataCapture(Visualizer v, byte[] f, int rate) {
                    synchronized (lock) { fft = f.clone(); visT = SystemClock.uptimeMillis(); }
                }
            }, Visualizer.getMaxCaptureRate(), true, true);
            vis.setEnabled(true);
        } catch (Exception e) {
            vis = null;
        }
    }

    private void stopVis() {
        if (vis != null) {
            try { vis.setEnabled(false); vis.release(); } catch (Exception ignored) { }
            vis = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        startVis();
        if (web != null) web.evaluateJavascript("window.__androidResume&&window.__androidResume()", null);
    }

    private static String artToData(Bitmap bm) {
        if (bm == null) return null;
        try {
            int w = bm.getWidth(), h = bm.getHeight(), m = Math.max(w, h);
            Bitmap sm = m > 300 ? Bitmap.createScaledBitmap(bm, Math.max(1, w * 300 / m), Math.max(1, h * 300 / m), true) : bm;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            sm.compress(Bitmap.CompressFormat.JPEG, 82, out);
            return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }

    private void mediaKey(int code) {
        long now = SystemClock.uptimeMillis();
        am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0));
        am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0));
    }

    /** Lo que la pantalla del estéreo (JavaScript) puede pedirle al celular. */
    public class Bridge {
        @JavascriptInterface
        public boolean hasAccess() { return MainActivity.this.hasAccess(); }

        @JavascriptInterface
        public boolean hasMic() { return MainActivity.this.hasMic(); }

        @JavascriptInterface
        public void askAccess() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
                catch (ActivityNotFoundException e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            });
        }

        @JavascriptInterface
        public void askMic() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            });
        }

        @JavascriptInterface
        public String media() {
            try {
                JSONObject o = new JSONObject();
                MediaController c = controller();
                if (c == null) { o.put("ok", false); o.put("access", hasAccess()); return o.toString(); }
                MediaMetadata md = c.getMetadata();
                PlaybackState st = c.getPlaybackState();
                String title = "", artist = "", album = "";
                long dur = 0;
                Bitmap art = null;
                if (md != null) {
                    CharSequence t = md.getText(MediaMetadata.METADATA_KEY_TITLE);
                    CharSequence a = md.getText(MediaMetadata.METADATA_KEY_ARTIST);
                    if (a == null) a = md.getText(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
                    CharSequence al = md.getText(MediaMetadata.METADATA_KEY_ALBUM);
                    title = t == null ? "" : t.toString();
                    artist = a == null ? "" : a.toString();
                    album = al == null ? "" : al.toString();
                    dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION);
                    art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                    if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                    if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                }
                int state = st == null ? 0 : st.getState();
                double pos = 0;
                if (st != null) {
                    pos = st.getPosition();
                    if (state == PlaybackState.STATE_PLAYING && st.getLastPositionUpdateTime() > 0) {
                        pos += (SystemClock.elapsedRealtime() - st.getLastPositionUpdateTime()) * st.getPlaybackSpeed();
                    }
                }
                String key = title + "|" + artist;
                if (!key.equals(artKey)) { artKey = key; artData = artToData(art); artPending = true; }
                else if (artData == null && art != null) { artData = artToData(art); artPending = true; }
                o.put("ok", title.length() > 0);
                o.put("app", c.getPackageName());
                o.put("title", title);
                o.put("artist", artist);
                o.put("album", album);
                o.put("dur", Math.max(0, dur) / 1000.0);
                o.put("pos", Math.max(0, pos) / 1000.0);
                o.put("status", state == PlaybackState.STATE_PLAYING ? 4 : 5);
                if (artPending) { o.put("artNew", true); o.put("art", artData == null ? JSONObject.NULL : artData); artPending = false; }
                return o.toString();
            } catch (Exception e) {
                return "{\"ok\":false}";
            }
        }

        @JavascriptInterface
        public void cmd(String c) {
            if ("volup".equals(c)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return; }
            if ("voldown".equals(c)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return; }
            MediaController m = controller();
            if (m != null) {
                MediaController.TransportControls tc = m.getTransportControls();
                PlaybackState st = m.getPlaybackState();
                boolean playing = st != null && st.getState() == PlaybackState.STATE_PLAYING;
                if ("play".equals(c)) { if (playing) tc.pause(); else tc.play(); }
                else if ("next".equals(c)) tc.skipToNext();
                else if ("prev".equals(c)) tc.skipToPrevious();
            } else {
                if ("play".equals(c)) mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);
                else if ("next".equals(c)) mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT);
                else if ("prev".equals(c)) mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS);
            }
        }

        /** Espectro (512 valores 0-255) + forma de onda (1024 bytes), en base64. Vacío si no hay sonido. */
        @JavascriptInterface
        public String audio() {
            byte[] f, w;
            long t;
            synchronized (lock) { f = fft; w = wave; t = visT; }
            if (f.length < 4 || SystemClock.uptimeMillis() - t > 1500) return "";
            int n = f.length / 2;
            byte[] out = new byte[n + w.length];
            for (int k = 0; k < n; k++) {
                double re, im;
                if (k == 0) { re = f[0]; im = 0; }
                else { re = f[2 * k]; im = f[2 * k + 1]; }
                double mag = Math.hypot(re, im);
                double db = 20 * Math.log10(mag / 128.0 + 1e-6);
                int v = (int) Math.round((db + 62) / 62 * 255);
                out[k] = (byte) Math.max(0, Math.min(255, v));
            }
            System.arraycopy(w, 0, out, n, w.length);
            return Base64.encodeToString(out, Base64.NO_WRAP);
        }

        @JavascriptInterface
        public int rate() { return visRate; }

        @JavascriptInterface
        public void resetArt() { artKey = ""; }

        /** Lista "a continuación" de la app de música (si la comparte). */
        @JavascriptInterface
        public String queue() {
            JSONArray arr = new JSONArray();
            try {
                MediaController c = controller();
                if (c == null) return arr.toString();
                List<MediaSession.QueueItem> q = c.getQueue();
                if (q == null) return arr.toString();
                PlaybackState st = c.getPlaybackState();
                long active = st == null ? -1 : st.getActiveQueueItemId();
                int n = 0;
                for (MediaSession.QueueItem it : q) {
                    if (n++ >= 60) break;
                    MediaDescription d = it.getDescription();
                    JSONObject o = new JSONObject();
                    o.put("id", it.getQueueId());
                    o.put("title", d.getTitle() == null ? "" : d.getTitle().toString());
                    o.put("artist", d.getSubtitle() == null ? "" : d.getSubtitle().toString());
                    o.put("now", it.getQueueId() == active);
                    Bitmap ic = d.getIconBitmap();
                    if (ic != null) {
                        try {
                            Bitmap sm = Bitmap.createScaledBitmap(ic, 96, Math.max(1, ic.getHeight() * 96 / Math.max(1, ic.getWidth())), true);
                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                            sm.compress(Bitmap.CompressFormat.JPEG, 75, out);
                            o.put("art", "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
                        } catch (Exception ignored) { }
                    } else if (d.getIconUri() != null) o.put("art", d.getIconUri().toString());
                    arr.put(o);
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public void skipTo(String id) {
            try { MediaController c = controller(); if (c != null) c.getTransportControls().skipToQueueItem(Long.parseLong(id)); } catch (Exception ignored) { }
        }

        /** Pide a la app de música que toque algo: una búsqueda ("artista canción") o, vacío, una mezcla. */
        @JavascriptInterface
        public void search(String q) {
            runOnUiThread(() -> {
                boolean done = false;
                try {
                    MediaController c = controller();
                    if (c != null) { c.getTransportControls().playFromSearch(q == null ? "" : q, new Bundle()); done = true; }
                } catch (Exception ignored) { }
                if (!done) {
                    Intent i = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
                    i.putExtra(SearchManager.QUERY, q == null ? "" : q);
                    i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*");
                    Intent app = findApp(new String[]{"youtube.music", "apps.youtube.music", "ytmusic", "spotify"}, "youtube music");
                    if (app != null && app.getComponent() != null) i.setPackage(app.getComponent().getPackageName());
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try { startActivity(i); } catch (Exception e) { if (app != null) try { startActivity(app); } catch (Exception ignored) { } }
                }
            });
        }

        /** Abre la búsqueda dentro de la app de música (para escoger tú la canción). */
        @JavascriptInterface
        public void openSearch(String q) {
            runOnUiThread(() -> {
                Intent app = findApp(new String[]{"youtube.music", "apps.youtube.music", "ytmusic"}, "youtube music");
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(q == null ? "" : q)));
                if (app != null && app.getComponent() != null) i.setPackage(app.getComponent().getPackageName());
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(i); } catch (Exception e) { i.setPackage(null); try { startActivity(i); } catch (Exception ignored) { } }
            });
        }

        @JavascriptInterface
        public void orient(String m) {
            final int o = "auto".equals(m) ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_USER
                    : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
            runOnUiThread(() -> setRequestedOrientation(o));
        }

        /** Aplica el preset del ecualizador al sonido real. Regresa cuántos ecualizadores quedaron activos. */
        @JavascriptInterface
        public int eq(String csv) {
            try {
                String[] p = csv.split(",");
                float[] w = new float[p.length];
                for (int k = 0; k < p.length; k++) w[k] = Float.parseFloat(p[k]);
                return EqManager.set(w);
            } catch (Exception e) { return 0; }
        }

        @JavascriptInterface
        public int battery() {
            try {
                BatteryManager bm = (BatteryManager) getSystemService(BATTERY_SERVICE);
                return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            } catch (Exception e) { return -1; }
        }

        @JavascriptInterface
        public void openApp(String id) {
            final String[] words;
            final String url;
            switch (id) {
                case "spotify": words = new String[]{"spotify"}; url = "https://open.spotify.com"; break;
                case "deezer": words = new String[]{"deezer"}; url = "https://www.deezer.com"; break;
                case "apple": words = new String[]{"apple.android.music"}; url = "https://music.apple.com"; break;
                case "amazon": words = new String[]{"amazon.mp3", "amazon.music"}; url = "https://music.amazon.com"; break;
                case "tidal": words = new String[]{"tidal"}; url = "https://listen.tidal.com"; break;
                case "soundcloud": words = new String[]{"soundcloud"}; url = "https://soundcloud.com"; break;
                default: words = new String[]{"youtube.music", "ytmusic", "youtubemusic"}; url = "https://music.youtube.com";
            }
            runOnUiThread(() -> {
                Intent i = findApp(words, id.equals("ytmusic") || id.isEmpty() ? "youtube music" : null);
                if (i == null) i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                try { startActivity(i); } catch (ActivityNotFoundException ignored) { }
            });
        }
    }

    /** Busca la app instalada aunque sea una versión modificada (por nombre del paquete o por el nombre que se ve). */
    private Intent findApp(String[] words, String label) {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        String found = null;
        for (android.content.pm.ResolveInfo r : apps) {
            String pkg = r.activityInfo.packageName.toLowerCase();
            for (String w : words) if (pkg.contains(w)) { found = r.activityInfo.packageName; break; }
            if (found != null) break;
        }
        if (found == null && label != null) {
            for (android.content.pm.ResolveInfo r : apps) {
                CharSequence l = r.loadLabel(pm);
                if (l != null && l.toString().toLowerCase().contains(label)) { found = r.activityInfo.packageName; break; }
            }
        }
        return found == null ? null : pm.getLaunchIntentForPackage(found);
    }
}
