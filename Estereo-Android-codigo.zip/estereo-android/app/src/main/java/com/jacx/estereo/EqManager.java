package com.jacx.estereo;

import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;

import java.util.HashMap;

/** Ecualizador real del celular: aplica el preset del estéreo (ROCK, POP, BASS...) al sonido. */
public class EqManager {
    static float[] w = {1, 1, 1, 1, 1};
    static boolean on = false;
    // en el iPod el ecualizador va apagado (así suena igual de fuerte que sin la app)
    static boolean suspended = false;
    private static final java.util.HashSet<Integer> sessions = new java.util.HashSet<>();
    static boolean flat(float[] a) { for (float v : a) if (Math.abs(v - 1f) > 0.02f) return false; return true; }
    static boolean active() { return on && !suspended && !flat(w); }
    private static final HashMap<Integer, Equalizer> eqs = new HashMap<>();
    // refuerzo de volumen (sube la música más allá del máximo normal del celular)
    static int boostMb = 0;
    private static final HashMap<Integer, LoudnessEnhancer> les = new HashMap<>();

    static synchronized int setBoost(int mb) {
        boostMb = Math.max(0, Math.min(2000, mb));
        if (les.isEmpty()) boostSession(0);
        int ok = 0;
        for (Integer s : new java.util.ArrayList<>(les.keySet())) if (boostSession(s)) ok++;
        return ok;
    }

    private static boolean boostSession(int session) {
        try {
            LoudnessEnhancer le = les.get(session);
            if (le == null) { le = new LoudnessEnhancer(session); les.put(session, le); }
            le.setTargetGain(boostMb);
            le.setEnabled(boostMb > 0);
            return true;
        } catch (Throwable ex) {
            LoudnessEnhancer le = les.remove(session);
            if (le != null) try { le.release(); } catch (Exception ignored) { }
            return false;
        }
    }

    static synchronized boolean attach(int session) {
        if (session < 0) return false;
        sessions.add(session);
        if (boostMb > 0) boostSession(session);
        if (!active()) return true;
        Equalizer e = eqs.get(session);
        if (e != null) { try { apply(e); return true; } catch (Exception ex) { eqs.remove(session); } }
        try {
            e = new Equalizer(1000, session);
            e.setEnabled(true);
            eqs.put(session, e);
            apply(e);
            return true;
        } catch (Throwable ex) {
            return false;
        }
    }

    static synchronized void release(int session) {
        sessions.remove(session);
        Equalizer e = eqs.remove(session);
        if (e != null) try { e.release(); } catch (Exception ignored) { }
        LoudnessEnhancer le = les.remove(session);
        if (le != null) try { le.release(); } catch (Exception ignored) { }
    }

    /** Cambia el preset; regresa cuántos ecualizadores quedaron activos. */
    static synchronized int set(float[] nw) {
        w = nw;
        on = true;
        return refresh();
    }

    /** Prende o quita los ecualizadores según el estado (apagado = sin efecto = volumen completo). */
    static synchronized int refresh() {
        if (!active()) {
            for (Equalizer e : eqs.values()) try { e.setEnabled(false); e.release(); } catch (Exception ignored) { }
            eqs.clear();
            return 0;
        }
        if (sessions.isEmpty()) attach(0); else for (Integer s0 : new java.util.ArrayList<>(sessions)) attach(s0);
        int ok = 0;
        for (Equalizer e : eqs.values()) {
            try { e.setEnabled(true); apply(e); ok++; } catch (Exception ignored) { }
        }
        return ok;
    }

    static synchronized void suspend(boolean sp) { suspended = sp; refresh(); }

    private static void apply(Equalizer e) {
        short[] r = e.getBandLevelRange();
        short n = e.getNumberOfBands();
        for (short b = 0; b < n; b++) {
            double f = e.getCenterFreq(b) / 1000.0;
            double p = (Math.log(Math.max(20, f)) - Math.log(60)) / (Math.log(14000) - Math.log(60));
            p = Math.max(0, Math.min(1, p));
            double x = p * (w.length - 1);
            int a = (int) Math.floor(x), c = Math.min(w.length - 1, a + 1);
            double t = x - a, wt = w[a] * (1 - t) + w[c] * t;
            double db = 20 * Math.log10(Math.max(0.05, wt)) * 2.4;
            db = Math.max(-12, Math.min(12, db));
            int mb = (int) Math.round(db * 100);
            mb = Math.max(r[0], Math.min(r[1], mb));
            e.setBandLevel(b, (short) mb);
        }
    }
}
