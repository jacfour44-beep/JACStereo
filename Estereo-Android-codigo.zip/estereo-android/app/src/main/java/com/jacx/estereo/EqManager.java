package com.jacx.estereo;

import android.media.audiofx.Equalizer;

import java.util.HashMap;

/** Ecualizador real del celular: aplica el preset del estéreo (ROCK, POP, BASS...) al sonido. */
public class EqManager {
    static float[] w = {1, 1, 1, 1, 1};
    static boolean on = false;
    private static final HashMap<Integer, Equalizer> eqs = new HashMap<>();

    static synchronized boolean attach(int session) {
        if (session < 0) return false;
        Equalizer e = eqs.get(session);
        if (e != null) { try { apply(e); return true; } catch (Exception ex) { eqs.remove(session); } }
        try {
            e = new Equalizer(1000, session);
            e.setEnabled(true);
            eqs.put(session, e);
            apply(e);
            return true;
        } catch (Throwable ex) {
            return false;
        }
    }

    static synchronized void release(int session) {
        Equalizer e = eqs.remove(session);
        if (e != null) try { e.release(); } catch (Exception ignored) { }
    }

    /** Cambia el preset; regresa cuántos ecualizadores quedaron activos. */
    static synchronized int set(float[] nw) {
        w = nw;
        on = true;
        if (eqs.isEmpty()) attach(0);
        int ok = 0;
        for (Equalizer e : eqs.values()) {
            try { e.setEnabled(true); apply(e); ok++; } catch (Exception ignored) { }
        }
        return ok;
    }

    private static void apply(Equalizer e) {
        short[] r = e.getBandLevelRange();
        short n = e.getNumberOfBands();
        for (short b = 0; b < n; b++) {
            double f = e.getCenterFreq(b) / 1000.0;
            double p = (Math.log(Math.max(20, f)) - Math.log(60)) / (Math.log(14000) - Math.log(60));
            p = Math.max(0, Math.min(1, p));
            double x = p * (w.length - 1);
            int a = (int) Math.floor(x), c = Math.min(w.length - 1, a + 1);
            double t = x - a, wt = w[a] * (1 - t) + w[c] * t;
            double db = 20 * Math.log10(Math.max(0.05, wt)) * 2.4;
            db = Math.max(-12, Math.min(12, db));
            int mb = (int) Math.round(db * 100);
            mb = Math.max(r[0], Math.min(r[1], mb));
            e.setBandLevel(b, (short) mb);
        }
    }
}
