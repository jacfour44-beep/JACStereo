# Estéreo JΛCX (Android)

Autoestéreo de los 2000 en tu celular: muestra lo que suena en YouTube Music, Spotify y otras apps
(nombre, artista, portada), la controla (play, pausa, siguiente, volumen) y sus escenas animadas se
mueven con la música. Creado por JΛCX.

**Descargar:** entra a *Releases* (a la derecha) y baja `Estereo-JACX.apk`.

Al abrirlo la primera vez:
1. **Dar acceso a la música** → activa *Estéreo JΛCX* en la lista.
2. **Permitir sonido** → para que los gráficos se muevan con la música.
3. Pon tu música y regresa al estéreo.
