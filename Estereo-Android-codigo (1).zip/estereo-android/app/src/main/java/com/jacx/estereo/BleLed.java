package com.jacx.estereo;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.UUID;

/** Tira LED Bluetooth "BJ_LED" (app bojiaLED / MohuanLED): se controla directo, sin abrir su app. */
class BleLed {
    private static final UUID WRITE_UUID = UUID.fromString("0000ee01-0000-1000-8000-00805f9b34fb");
    private static final String[] ALT_UUIDS = {"0000ffe1-0000-1000-8000-00805f9b34fb", "0000ffd9-0000-1000-8000-00805f9b34fb", "0000fff3-0000-1000-8000-00805f9b34fb"};

    private final Context ctx;
    private final SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic wc;
    private final ArrayDeque<byte[]> queue = new ArrayDeque<>();
    private boolean writing = false, scanning = false;
    volatile String status = "Sin conectar";
    volatile String name = "", info = "";
    volatile boolean on = true;
    volatile int r = 255, g = 255, b = 255;
    private ScanCallback scanCb;

    BleLed(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("jacx", Context.MODE_PRIVATE);
        name = sp.getString("ledName", "");
        on = sp.getBoolean("ledOn", true);
        int col = sp.getInt("ledColor", 0xFFFFFF);
        r = (col >> 16) & 255; g = (col >> 8) & 255; b = col & 255;
    }

    private BluetoothAdapter adapter() {
        BluetoothManager m = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
        return m == null ? null : m.getAdapter();
    }

    boolean ready() { return gatt != null && wc != null; }

    String state() {
        try {
            JSONObject o = new JSONObject();
            o.put("status", status); o.put("name", name); o.put("ready", ready()); o.put("on", on);
            o.put("color", String.format("#%02x%02x%02x", r, g, b)); o.put("info", info);
            BluetoothAdapter a = adapter();
            o.put("bt", a != null && a.isEnabled());
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    /** Conectar: a la tira que ya conocemos o buscando una que se llame BJ_LED... */
    void connect() {
        h.post(() -> {
            try {
                BluetoothAdapter a = adapter();
                if (a == null) { status = "Esta tablet no tiene Bluetooth"; return; }
                if (!a.isEnabled()) { status = "Prende el Bluetooth"; return; }
                if (ready()) { status = "Conectada"; return; }
                String mac = sp.getString("ledMac", "");
                if (!mac.isEmpty()) { open(a.getRemoteDevice(mac)); return; }
                scan(a);
            } catch (SecurityException e) { status = "Falta permiso de Bluetooth"; }
            catch (Exception e) { status = "Error: " + e.getClass().getSimpleName(); }
        });
    }

    void forget() {
        sp.edit().remove("ledMac").remove("ledName").apply();
        name = "";
        disconnect();
        status = "Sin conectar";
    }

    private void scan(BluetoothAdapter a) {
        if (scanning) return;
        final BluetoothLeScanner sc = a.getBluetoothLeScanner();
        if (sc == null) { status = "Prende el Bluetooth"; return; }
        status = "Buscando la tira…";
        scanning = true;
        scanCb = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult res) {
                try {
                    BluetoothDevice d = res.getDevice();
                    String n = d.getName();
                    if (n == null && res.getScanRecord() != null) n = res.getScanRecord().getDeviceName();
                    if (n != null && n.toUpperCase().startsWith("BJ_LED")) {
                        stopScan(sc);
                        name = n;
                        sp.edit().putString("ledMac", d.getAddress()).putString("ledName", n).apply();
                        open(d);
                    }
                } catch (SecurityException ignored) { }
            }
            @Override public void onScanFailed(int code) { scanning = false; status = "No se pudo buscar (" + code + "). Prende la ubicación"; }
        };
        try { sc.startScan(scanCb); } catch (SecurityException e) { scanning = false; status = "Falta permiso de Bluetooth"; return; }
        h.postDelayed(() -> { if (scanning) { stopScan(sc); status = "No encontré la tira. ¿Está prendida? Cierra bojiaLED en el cel"; } }, 15000);
    }

    private void stopScan(BluetoothLeScanner sc) {
        scanning = false;
        try { sc.stopScan(scanCb); } catch (Exception ignored) { }
    }

    private void open(BluetoothDevice d) {
        status = "Conectando…";
        try {
            if (gatt != null) { try { gatt.close(); } catch (Exception ignored) { } gatt = null; }
            BluetoothGattCallback cb = new BluetoothGattCallback() {
                @Override public void onConnectionStateChange(BluetoothGatt gt, int st, int ns) {
                    if (ns == BluetoothProfile.STATE_CONNECTED) { status = "Conectada, preparando…"; try { gt.discoverServices(); } catch (SecurityException ignored) { } }
                    else if (ns == BluetoothProfile.STATE_DISCONNECTED) {
                        wc = null; writing = false;
                        try { gt.close(); } catch (Exception ignored) { }
                        if (gatt == gt) gatt = null;
                        status = st == 0 ? "Desconectada" : "No se pudo conectar (" + st + "). Cierra bojiaLED en el cel";
                    }
                }
                @Override public void onServicesDiscovered(BluetoothGatt gt, int st) {
                    StringBuilder sb = new StringBuilder();
                    BluetoothGattCharacteristic found = null, any = null;
                    for (BluetoothGattService s : gt.getServices()) {
                        for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                            String u = c.getUuid().toString().substring(4, 8);
                            int p = c.getProperties();
                            boolean w = (p & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0;
                            sb.append(u).append(w ? "w " : " ");
                            if (c.getUuid().equals(WRITE_UUID)) found = c;
                            if (found == null) for (String alt : ALT_UUIDS) if (c.getUuid().toString().equals(alt)) any = c;
                            String su = s.getUuid().toString();
                            if (w && any == null && !su.startsWith("00001800") && !su.startsWith("00001801") && !su.startsWith("0000180a")) any = c;
                        }
                    }
                    info = sb.toString().trim();
                    wc = found != null ? found : any;
                    if (wc == null) { status = "La tira no aceptó órdenes (" + info + ")"; return; }
                    status = "Conectada";
                    if (name.isEmpty()) { try { name = gt.getDevice().getName(); } catch (SecurityException ignored) { } }
                    pump();
                }
                @Override public void onCharacteristicWrite(BluetoothGatt gt, BluetoothGattCharacteristic c, int st) {
                    writing = false;
                    h.postDelayed(BleLed.this::pump, 25);
                }
            };
            gatt = Build.VERSION.SDK_INT >= 23 ? d.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE) : d.connectGatt(ctx, false, cb);
            h.postDelayed(() -> { if (!ready() && "Conectando…".equals(status)) status = "Tarda en conectar… ¿está prendida y cerca?"; }, 12000);
        } catch (SecurityException e) { status = "Falta permiso de Bluetooth"; }
    }

    void disconnect() {
        try { if (gatt != null) { gatt.disconnect(); gatt.close(); } } catch (Exception ignored) { }
        gatt = null; wc = null; writing = false;
    }

    private static byte[] hex(String s) {
        String[] p = s.trim().split(" ");
        byte[] out = new byte[p.length];
        for (int i = 0; i < p.length; i++) out[i] = (byte) Integer.parseInt(p[i], 16);
        return out;
    }

    private void send(byte[] data) {
        h.post(() -> {
            if (queue.size() > 20) queue.clear();
            queue.add(data);
            if (!ready()) connect(); else pump();
        });
    }

    private void pump() {
        if (writing || !ready()) return;
        byte[] d = queue.poll();
        if (d == null) return;
        try {
            int p = wc.getProperties();
            wc.setWriteType((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0 ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            wc.setValue(d);
            writing = gatt.writeCharacteristic(wc);
            if (!writing) h.postDelayed(this::pump, 60);
            else h.postDelayed(() -> { if (writing) { writing = false; pump(); } }, 400);
        } catch (SecurityException e) { status = "Falta permiso de Bluetooth"; }
    }

    void power(boolean onNow) {
        on = onNow;
        sp.edit().putBoolean("ledOn", onNow).apply();
        send(hex(onNow ? "69 96 02 01 01" : "69 96 02 01 00"));
    }

    void color(int rr, int gg, int bb) {
        r = rr & 255; g = gg & 255; b = bb & 255;
        sp.edit().putInt("ledColor", (r << 16) | (g << 8) | b).apply();
        if (!on) power(true);
        send(new byte[]{0x69, (byte) 0x96, 0x05, 0x02, (byte) r, (byte) g, (byte) b});
    }

    /** Efectos de la tira: mode 0..21, speed 1 (rápido) .. 10 (lento). */
    void effect(int mode, int speed) {
        if (!on) power(true);
        send(new byte[]{0x69, (byte) 0x96, 0x03, 0x03, (byte) Math.max(0, Math.min(21, mode)), (byte) Math.max(1, Math.min(10, speed))});
    }
}
