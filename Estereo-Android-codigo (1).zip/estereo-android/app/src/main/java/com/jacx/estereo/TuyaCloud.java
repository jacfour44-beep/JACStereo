package com.jacx.estereo;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Tira Steren (Wi-Fi) a través de la nube de Tuya / Smart Life.
 * Necesita el Access ID y Access Secret del proyecto del usuario en platform.tuya.com
 * (se escriben en la tablet; nunca van dentro de la app ni en GitHub).
 */
class TuyaCloud {
    private final SharedPreferences sp;
    private String token = "";
    private long tokenExp = 0;
    volatile String status = "Sin configurar";
    volatile String devName = "";
    private String colorCode = "colour_data_v2", brightCode = "bright_value_v2";
    private boolean colorV2 = true;

    TuyaCloud(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("jacx", Context.MODE_PRIVATE);
        devName = sp.getString("tyName", "");
        colorCode = sp.getString("tyColor", colorCode);
        brightCode = sp.getString("tyBright", brightCode);
        colorV2 = colorCode.endsWith("_v2");
        if (configured()) status = devName.isEmpty() ? "Lista para buscar la tira" : "Lista";
    }

    String base() { return sp.getString("tyHost", "https://openapi.tuyaus.com"); }
    String id() { return sp.getString("tyId", ""); }
    String secret() { return sp.getString("tySecret", ""); }
    String dev() { return sp.getString("tyDev", ""); }
    boolean configured() { return !id().isEmpty() && !secret().isEmpty(); }

    void save(String id, String secret, String host) {
        sp.edit().putString("tyId", id.trim()).putString("tySecret", secret.trim())
                .putString("tyHost", host == null || host.trim().isEmpty() ? "https://openapi.tuyaus.com" : host.trim())
                .remove("tyDev").remove("tyName").apply();
        token = ""; tokenExp = 0; devName = "";
        status = "Guardado. Buscando la tira…";
    }

    void forget() {
        sp.edit().remove("tyId").remove("tySecret").remove("tyDev").remove("tyName").apply();
        token = ""; devName = ""; status = "Sin configurar";
    }

    String state() {
        try {
            JSONObject o = new JSONObject();
            o.put("configured", configured()); o.put("status", status); o.put("name", devName); o.put("ready", configured() && !dev().isEmpty());
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    // ---------- firma de Tuya (HMAC-SHA256) ----------
    private static String sha256(String s) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));
        StringBuilder b = new StringBuilder(); for (byte x : d) b.append(String.format("%02x", x)); return b.toString();
    }
    private static String hmac(String key, String s) throws Exception {
        Mac m = Mac.getInstance("HmacSHA256"); m.init(new SecretKeySpec(key.getBytes("UTF-8"), "HmacSHA256"));
        byte[] d = m.doFinal(s.getBytes("UTF-8"));
        StringBuilder b = new StringBuilder(); for (byte x : d) b.append(String.format("%02X", x)); return b.toString();
    }

    private JSONObject call(String method, String path, String body, boolean withToken) throws Exception {
        String t = String.valueOf(System.currentTimeMillis()), nonce = UUID.randomUUID().toString();
        String strToSign = method + "\n" + sha256(body == null ? "" : body) + "\n\n" + path;
        String tk = withToken ? token : "";
        String sign = hmac(secret(), id() + tk + t + nonce + strToSign);
        HttpURLConnection h = (HttpURLConnection) new URL(base() + path).openConnection();
        try {
            h.setConnectTimeout(8000); h.setReadTimeout(10000); h.setRequestMethod(method);
            h.setRequestProperty("client_id", id()); h.setRequestProperty("t", t); h.setRequestProperty("nonce", nonce);
            h.setRequestProperty("sign_method", "HMAC-SHA256"); h.setRequestProperty("sign", sign);
            if (withToken) h.setRequestProperty("access_token", tk);
            h.setRequestProperty("Content-Type", "application/json");
            if (body != null) { h.setDoOutput(true); h.getOutputStream().write(body.getBytes("UTF-8")); }
            InputStream in = h.getResponseCode() >= 400 ? h.getErrorStream() : h.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int n;
            if (in != null) while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return new JSONObject(bo.size() == 0 ? "{}" : bo.toString("UTF-8"));
        } finally { h.disconnect(); }
    }

    private boolean ensureToken() throws Exception {
        if (!token.isEmpty() && System.currentTimeMillis() < tokenExp - 60000) return true;
        JSONObject r = call("GET", "/v1.0/token?grant_type=1", null, false);
        if (!r.optBoolean("success")) { status = "Clave no aceptada: " + r.optString("msg", "revisa Access ID y Secret"); return false; }
        JSONObject res = r.getJSONObject("result");
        token = res.getString("access_token");
        tokenExp = System.currentTimeMillis() + res.optLong("expire_time", 7200) * 1000;
        return true;
    }

    /** Busca la tira de luces entre los aparatos vinculados al proyecto. */
    synchronized boolean findDevice() {
        try {
            if (!configured()) { status = "Sin configurar"; return false; }
            if (!ensureToken()) return false;
            JSONObject r = call("GET", "/v2.0/cloud/thing/device?page_size=20", null, true);
            if (!r.optBoolean("success")) { status = "No pude ver tus aparatos: " + r.optString("msg"); return false; }
            Object res = r.opt("result");
            JSONArray list = res instanceof JSONArray ? (JSONArray) res : (res instanceof JSONObject ? ((JSONObject) res).optJSONArray("list") : null);
            if (list == null || list.length() == 0) { status = "No hay aparatos. Vincula tu cuenta de Smart Life al proyecto"; return false; }
            JSONObject pick = null;
            for (int i = 0; i < list.length(); i++) {
                JSONObject d = list.getJSONObject(i);
                String cat = d.optString("category"), name = d.optString("name", d.optString("customName")).toLowerCase(Locale.ROOT);
                if (cat.equals("dd") || cat.equals("dj") || cat.equals("fwd") || name.contains("shome") || name.contains("tira") || name.contains("led")) { pick = d; break; }
            }
            if (pick == null) pick = list.getJSONObject(0);
            String id = pick.getString("id");
            String nm = pick.optString("customName", "");
            if (nm.isEmpty()) nm = pick.optString("name", "Tira Steren");
            // ver qué órdenes entiende (color v1 o v2, brillo)
            try {
                JSONObject f = call("GET", "/v1.0/iot-03/devices/" + id + "/functions", null, true);
                JSONArray fs = f.optJSONObject("result") == null ? null : f.getJSONObject("result").optJSONArray("functions");
                if (fs != null) {
                    boolean c2 = false, c1 = false, b2 = false, b1 = false;
                    for (int i = 0; i < fs.length(); i++) {
                        String c = fs.getJSONObject(i).optString("code");
                        if (c.equals("colour_data_v2")) c2 = true; if (c.equals("colour_data")) c1 = true;
                        if (c.equals("bright_value_v2")) b2 = true; if (c.equals("bright_value")) b1 = true;
                    }
                    colorCode = c2 ? "colour_data_v2" : c1 ? "colour_data" : colorCode;
                    brightCode = b2 ? "bright_value_v2" : b1 ? "bright_value" : brightCode;
                    colorV2 = colorCode.endsWith("_v2");
                }
            } catch (Exception ignored) { }
            sp.edit().putString("tyDev", id).putString("tyName", nm).putString("tyColor", colorCode).putString("tyBright", brightCode).apply();
            devName = nm;
            status = pick.optBoolean("online", true) ? "Lista" : "La tira está desconectada del Wi-Fi";
            return true;
        } catch (Exception e) { status = "Sin internet o clave mal escrita (" + e.getClass().getSimpleName() + ")"; return false; }
    }

    private synchronized void send(JSONArray cmds) {
        try {
            if (!configured()) { status = "Sin configurar"; return; }
            if (dev().isEmpty() && !findDevice()) return;
            if (!ensureToken()) return;
            JSONObject body = new JSONObject().put("commands", cmds);
            JSONObject r = call("POST", "/v1.0/iot-03/devices/" + dev() + "/commands", body.toString(), true);
            if (r.optBoolean("success")) status = "Lista";
            else {
                String msg = r.optString("msg", "error");
                if (r.optInt("code") == 1010 || r.optInt("code") == 1011) { token = ""; }
                status = "No obedeció: " + msg;
            }
        } catch (Exception e) { status = "Sin internet (" + e.getClass().getSimpleName() + ")"; }
    }

    private static JSONObject cmd(String code, Object value) throws Exception { return new JSONObject().put("code", code).put("value", value); }

    void power(final boolean on) {
        new Thread(() -> { try { send(new JSONArray().put(cmd("switch_led", on))); } catch (Exception ignored) { } }).start();
    }

    /** Color RGB 0-255 (el brillo ya viene metido en el color). */
    void color(final int r, final int g, final int b) {
        new Thread(() -> {
            try {
                float[] hsv = new float[3];
                android.graphics.Color.RGBToHSV(r, g, b, hsv);
                JSONArray c = new JSONArray().put(cmd("switch_led", true));
                boolean white = hsv[1] < 0.08f;
                if (white) {
                    c.put(cmd("work_mode", "white"));
                    int v = Math.max(10, Math.round(hsv[2] * (colorV2 ? 1000 : 255)));
                    c.put(cmd(brightCode, v));
                } else {
                    c.put(cmd("work_mode", "colour"));
                    JSONObject col = new JSONObject();
                    int m = colorV2 ? 1000 : 255;
                    col.put("h", Math.round(hsv[0])); col.put("s", Math.round(hsv[1] * m)); col.put("v", Math.max(10, Math.round(hsv[2] * m)));
                    c.put(cmd(colorCode, colorV2 ? col : col.toString()));
                }
                send(c);
            } catch (Exception ignored) { }
        }).start();
    }

    /** Efectos: la tira trae los suyos; aquí se usa el modo "escena" o "música". */
    void effect(final int i) {
        new Thread(() -> { try { send(new JSONArray().put(cmd("switch_led", true)).put(cmd("work_mode", i % 2 == 0 ? "scene" : "music"))); } catch (Exception ignored) { } }).start();
    }
}
